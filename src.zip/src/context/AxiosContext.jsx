import { createContext } from 'react';

export const AxiosContext = createContext(null);