import { Outlet } from "react-router"

function OfficeInfo() {
  return (
    <div>
      <h1>OfficeInfo</h1>
      <Outlet />
    </div>
  )
}

export default OfficeInfo