import React from 'react'

function ContractProceeding() {
  return (
    <div>ContractProceeding</div>
  )
}

export default ContractProceeding