import { Outlet } from 'react-router'

function Contract() {
  return (
    <>
      <Outlet />
    </>
  )
}

export default Contract