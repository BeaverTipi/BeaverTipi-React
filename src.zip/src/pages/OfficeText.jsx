import React from 'react'

function OfficeText() {
  return (
    <div>OfficeText</div>
  )
}

export default OfficeText