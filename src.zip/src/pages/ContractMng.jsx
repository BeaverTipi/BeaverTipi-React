import React from 'react'

function ContractMng() {
  return (
    <div>ContractMng</div>
  )
}

export default ContractMng