import { createContext } from 'react';

//AES 암호화 키
// const secretKey = "7gXh8WzK4rD2pR9t6LcYvBN1eQm3AZUs";
// const iv = "eK9fG6pW4dMxV2sR";
export const AESContext = createContext(null);


