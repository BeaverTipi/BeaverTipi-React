import { Outlet } from 'react-router'

function Contract() {
  return (
    <>
      <div>Contract</div>
      <Outlet />
    </>
  )
}

export default Contract