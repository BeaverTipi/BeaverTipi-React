/*
ContractNew.jsx (최상위)
│
├── STEP.SELECT
│   └── ContractListingSelect
│
├── STEP.ADD_TENANCY
│   └── AddTenancy
│
├── STEP.ADD_LESSEE
│   └── AddLessee
│
├── STEP.SAMPLE_SELECT
│   └── ContractSampleSelect
│
├── STEP.SAMPLE_WRITE
│   └── ContractWriterForm
│       └── StandardLeaseForm.jsx (sampleId 기준 렌더링)
│           ├── HousingContractForm
│           ├── ContractTermsSection
│           ├── ContractLawSection
│           ├── ContractSpecialTerms
│           ├── ContractSignSection
│
├── STEP.PDF_PREVIEW
│   └── ContractPreview (→ ContractPDFRenderer 내부 사용)
│
└── STEP.CONTRACT
    └── ContractTermsForm
        ├── ContractPartyLoader
        ├── ContractFileUpLoader
        └── ContractPDFLoader
 */

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useSecureAxios } from "../hooks/useSecureAxios.js";
import ContractListingSelect from "../components/myOfficeContract/contractNew/ContractListingSelect";
import AddTenancy from "../components/myOfficeContract/contractNew/AddTenancy.jsx";
import AddLessee from "../components/myOfficeContract/contractNew/AddLessee";
import ContractSampleSelect from "../components/myOfficeContract/contractNew/ContractSampleSelect";
import ContractWriterForm from "../components/myOfficeContract/contractNew/ContractWriterForm";
import ContractPreview from "../components/myOfficeContract/contractNew/ContractPreview.jsx";
import NewContractInfoLayout from "../components/myOfficeContract/contractNew/NewContractInfoLayout.jsx";
import ContractNewStepNavigation from "../components/myOfficeContract/contractNew/ContractNewStepNavigation.jsx";
import { fillPdfStandardLeaseFormWithFormData } from "../components/ContractSample/StandardLeaseForm/fillPdfStandardLeaseForm";
import pdfTemplate from "../components/ContractSample/표준임대차계약서.pdf"; // Vite/Webpack 설정에 따라 import 방식 다를 수 있음
import { ContractInfoProvider, useContractInfo } from "../context/ContractInfoContext";

const STEP = {
  SELECT: "select",
  ADD_TENANCY: "add-tenancy",
  ADD_LESSEE: "add-lessee",
  SAMPLE_SELECT: "sample-select",
  SAMPLE_WRITE: "write",
  PDF_PREVIEW: "pdf-preview",
  CONTRACT: "contract",
};

function ContractNew() {
  const [isFirstRender, setIsFirstRender] = useState(true);
  // const [contractInfo, setContractInfo] = useState(contractInfoReset);
  const [contractFileWritten, setContractFileWritten] = useState(null);
  const [step, setStep] = useState(STEP.SELECT);
  const [stepHistory, setStepHistory] = useState([]);
  const [direction, setDirection] = useState("forward");
  const [tenancyNo, setTenancyNo] = useState(1);
  const {
    contractInfo
    , setContractInfo
    , updateListingInfo
    , updateLessorInfo
    , updateLesseeInfo
    , updateSampleId
    , updateWrittenInfo
    , updateAttachedFiles
  } = useContractInfo();
  const contractInfoReset = {
    files: null,
  };

  useEffect(() => {
    //컴포넌트 전환 애니메이션 STEP
    if (step === STEP.SELECT) {
      setIsFirstRender(false);
    }
  }, [step]);

  useEffect(() => {
    // 부드럽게 최상단으로 스크롤
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [step]);

  const goToStep = (nextStep) => {
    setStepHistory((prev) => [...prev, step]);
    setDirection("forward");
    setStep(nextStep);
  };

  const handleListingSaved = (selectedListing) => {
    //최초 단계를 재수행할 시, 기록된 정보 모두 초기화
    setContractInfo(contractInfoReset);
    updateListingInfo(selectedListing);
    if (!selectedListing.tenancyInfo) goToStep(STEP.ADD_TENANCY);
    else goToStep(STEP.ADD_LESSEE);
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handleTenancySaved = (tenancyInfo) => {
    goToStep(STEP.ADD_LESSEE);
    updateLessorInfo(tenancyInfo)
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handleLesseeSaved = (lesseeInfo) => {
    updateLesseeInfo(lesseeInfo);
    goToStep(STEP.SAMPLE_SELECT);
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handleSampleIdSaved = (sampleId) => {
    updateSampleId(sampleId);
    goToStep(STEP.SAMPLE_WRITE);
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handleWrittenSaved = contract => {
    updateWrittenInfo(contract);
    goToStep(STEP.PDF_PREVIEW);
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handlePreviewSaved = (pdfFile) => {
    setContractInfo((prev) => ({
      ...prev,
      confirmedAt: new Date(), // ✅ 확인 시간 추가 등 가능
    }));
    setContractFileWritten(pdfFile);
    goToStep(STEP.CONTRACT);
    console.log(`%c[전환]`, "color:yellow; font-weight:bold;", contractInfo);
  };

  const handleFilesUploaded = (files) => {
    updateAttachedFiles(files);
  };

  const handleBack = () => {
    if (stepHistory.length > 0) {
      const prevStep = stepHistory[stepHistory.length - 1];
      setStepHistory((prev) => prev.slice(0, -1)); // pop
      setDirection("backward");
      setStep(prevStep);
    }
  };

  //애니메이션 설정
  const variants = {
    initial: (direction) => ({
      x: direction === "forward" ? "100%" : "-100%",
      opacity: 0,
      position: "absolute",
      width: "100%",
    }),
    animate: {
      x: 0,
      opacity: 1,
      transition: { duration: 0.4, ease: "easeInOut" },
    },
    exit: (direction) => ({
      x: direction === "forward" ? "-100%" : "100%",
      opacity: 0,
      transition: { duration: 0.4, ease: "easeInOut" },
    }),
  };
  return (
    <>
      <ContractNewStepNavigation step={step} STEP={STEP} />
      <div className="relative w-full min-h-screen">
        {/* 브라우저 높이 기준으로 스크롤 */}
        <AnimatePresence custom={direction} mode="wait">
          {step === STEP.SELECT &&
            (isFirstRender ? (
              <div key="select" className="w-full">
                <ContractListingSelect
                  onSave={handleListingSaved}
                />
              </div>
            ) : (
              <motion.div
                key="select"
                custom={direction}
                variants={variants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <ContractListingSelect
                  onSave={handleListingSaved}
                />
              </motion.div>
            ))}

          {step === STEP.ADD_TENANCY && (
            <motion.div
              key="add-tenancy"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <AddTenancy
                onSave={handleTenancySaved}
                onBack={handleBack}
                tenancyNo={tenancyNo}
                setTenancyNo={setTenancyNo}
              />
            </motion.div>
          )}

          {step === STEP.ADD_LESSEE && (
            <motion.div
              key="add-lessee"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <AddLessee
                lessee={contractInfo.lessee}
                lstgId={contractInfo.listing?.lstgId}
                onSave={handleLesseeSaved}
                onBack={handleBack}
              />
            </motion.div>
          )}

          {step === STEP.SAMPLE_SELECT && (
            <motion.div
              key="sample-select"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <ContractSampleSelect
                onNext={handleSampleIdSaved}
                onBack={handleBack}
              />
            </motion.div>
          )}

          {step === STEP.SAMPLE_WRITE && contractInfo.sampleId && (
            <motion.div
              key="sample-write"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <ContractWriterForm
                sampleId={contractInfo.sampleId}
                onSave={handleWrittenSaved}
                onBack={handleBack}
              />
            </motion.div>
          )}

          {step === STEP.PDF_PREVIEW && (
            <motion.div
              key="pdf-preview"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <ContractPreview
                onConfirm={handlePreviewSaved}
                onBack={handleBack}
                onExtract={(file) => setContractFileWritten(file)}
              />
            </motion.div>
          )}

          {step === STEP.CONTRACT && (
            <motion.div
              key="contract"
              custom={direction}
              variants={variants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <NewContractInfoLayout
                onFilesUploaded={handleFilesUploaded}
                onBack={handleBack}
                attachedFile={contractFileWritten}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}

export default ContractNew;
