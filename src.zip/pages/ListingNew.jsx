import React from 'react'

function ListingNew() {
  return (
    <div>ListingNew</div>
  )
}

export default ListingNew